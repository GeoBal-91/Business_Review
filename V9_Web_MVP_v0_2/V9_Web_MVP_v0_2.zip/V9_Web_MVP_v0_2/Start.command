#!/bin/zsh
set -e
v9_app_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$v9_app_dir"
if [[ ! -x .venv/bin/python ]]; then
  print 'First-time setup is needed. Follow the Python 3.12 instructions in README.md.'
  print 'Press Return to close.'
  read -r
  exit 1
fi
print 'Glovo Partner Insights — starting your local workspace.'
print 'Keep this window open while you use the app. Control-C stops it.'
exec .venv/bin/python -m streamlit run app.py
